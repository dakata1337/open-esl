%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-03-09T14:14:57+02:00*%
%TF.ProjectId,pcb-spacer,7063622d-7370-4616-9365-722e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-03-09 14:14:57*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.200000*%
%ADD11RoundRect,0.250000X-0.250000X-0.750000X0.250000X-0.750000X0.250000X0.750000X-0.250000X0.750000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X78000000Y-150000000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X74000000Y-50000000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X57000000Y-100000000D03*
%TD*%
D11*
%TO.C,J1*%
X100000000Y-161250000D03*
%TD*%
D10*
%TO.C,REF\u002A\u002A*%
X122000000Y-150000000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X143000000Y-100000000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X126000000Y-50000000D03*
%TD*%
M02*
